﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class ProductModuleForm : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\dbPC.mdf;Integrated Security=True");
        SqlCommand cm = new SqlCommand();
        SqlDataReader dr;
        public ProductModuleForm()
        {
            InitializeComponent();
            LoadCategory();
        }
        private bool ValidateFields()
        {
            if (string.IsNullOrWhiteSpace(txtProductName.Text) ||
                string.IsNullOrWhiteSpace(txtQuantity.Text) ||
                string.IsNullOrWhiteSpace(txtPrice.Text) ||
                string.IsNullOrWhiteSpace(txtDesc.Text) ||
                string.IsNullOrWhiteSpace(combCat.Text))
            {
                MessageBox.Show("Please fill in all fields.", "Validation Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        public void LoadCategory()
        {
            combCat.Items.Clear();
            cm = new SqlCommand("SELECT ctname FROM tbCategory", con);
            con.Open();
            dr = cm.ExecuteReader();
            while(dr.Read())
            {
                combCat.Items.Add(dr[0].ToString());
            }
            dr.Close();
            con.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (!ValidateFields())
            {
                return;
            }
            try
            {
                if (MessageBox.Show("Are you sure you want to save this Product?", "Saving", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cm = new SqlCommand("INSERT INTO tbProduct(pname,pquantity,pprice,pdescription,pcategory)VALUES(@pname,@pquantity,@pprice,@pdescription,@pcategory)", con);
                    cm.Parameters.AddWithValue("@pname", txtProductName.Text);
                    cm.Parameters.AddWithValue("@pquantity", Convert.ToInt16(txtQuantity.Text));
                    cm.Parameters.AddWithValue("@pprice", Convert.ToInt32(txtPrice.Text));
                    cm.Parameters.AddWithValue("@pdescription", txtDesc.Text);
                    cm.Parameters.AddWithValue("@pcategory", combCat.Text);
                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Product successfully Saved");
                    Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            if (!ValidateFields())
            {
                return;
            }
            try
            {
                if (MessageBox.Show("Are you sure you want to update this user?", "Updating", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cm = new SqlCommand("UPDATE tbProduct SET pname=@pname,pquantity=@pquantity,pprice=@pprice,pdescription=@pdescription,pcategory=@pcategory WHERE pid LIKE '" + lblPid.Text + "' ", con);
                    cm.Parameters.AddWithValue("@pname", txtProductName.Text);
                    cm.Parameters.AddWithValue("@pquantity", Convert.ToInt16(txtQuantity.Text));
                    cm.Parameters.AddWithValue("@pprice", Convert.ToInt32(txtPrice.Text));
                    cm.Parameters.AddWithValue("@pdescription", txtDesc.Text);
                    cm.Parameters.AddWithValue("@pcategory", combCat.Text);
                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Product successfully Updated");
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            Clear();
            saveButton.Enabled = true;
            updateButton.Enabled = false;
        }
        public void Clear()
        {
            txtProductName.Clear();
            txtQuantity.Clear();
            txtPrice.Clear();
            txtDesc.Clear();
            combCat.Text = "";
        }
        private void txtProductName_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtProductName.Text))
            {
                errorProvider1.SetError(txtProductName, "Product Name cannot be empty");
                txtProductName.Focus();
            }
            else
            {
                errorProvider1.SetError(txtProductName, "");
            }
        }
        private void txtQuantity_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtQuantity.Text))
            {
                errorProvider1.SetError(txtProductName, "Quantity cannot be empty");
                txtProductName.Focus();
            }
            else
            {
                errorProvider1.SetError(txtProductName, "");
            }
        }
        private void txtPrice_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPrice.Text))
            {
                errorProvider1.SetError(txtProductName, "Price cannot be empty");
                txtProductName.Focus();
            }
            else
            {
                errorProvider1.SetError(txtProductName, "");
            }
        }
        private void txtDescription_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtProductName.Text))
            {
                errorProvider1.SetError(txtProductName, "Description cannot be empty");
                txtProductName.Focus();
            }
            else
            {
                errorProvider1.SetError(txtProductName, "");
            }
        }
        private void txtPCategory_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(combCat.Text))
            {
                errorProvider1.SetError(txtProductName, "Category cannot be empty");
                txtProductName.Focus();
            }
            else
            {
                errorProvider1.SetError(txtProductName, "");
            }
        }
    }
}
