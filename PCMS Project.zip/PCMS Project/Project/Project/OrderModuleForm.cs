﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class OrderModuleForm : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Administrator\Desktop\PCMS Project\dbPC.mdf;Integrated Security=True;");
        SqlCommand cm = new SqlCommand();
        SqlDataReader dr;
        int quantity = 0;
        public OrderModuleForm()
        {
            InitializeComponent();
            LoadCustomer();
            LoadProduct();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
        public void LoadCustomer()
        {
            int i = 0;
            customerGridView.Rows.Clear();
            cm = new SqlCommand("SELECT cid,cname FROM tbCustomer WHERE CONCAT(cid,cname) LIKE '%"+txtSearchCus.Text+"%'", con);
            con.Open();
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                customerGridView.Rows.Add(i, dr[0].ToString(), dr[1].ToString());
            }
            dr.Close();
            con.Close();
        }
        public void LoadProduct()
        {
            int i = 0;
            productGridView.Rows.Clear();
            cm = new SqlCommand("SELECT * FROM tbProduct WHERE CONCAT(pname, pprice, pdescription, pcategory) LIKE '%" + txtSearchPro.Text + "%'", con);
            con.Open();
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                productGridView.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString());
            }
            dr.Close();
            con.Close();
        }
        private void txtSearchCus_TextChanged(object sender, EventArgs e)
        {
            LoadCustomer();
        }

        private void txtSearchPro_TextChanged(object sender, EventArgs e)
        {
            LoadProduct();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            GetQty();
            if (Convert.ToInt32(numericUpDown1.Value)>quantity)
            {
                MessageBox.Show("Not enough in stock!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                numericUpDown1.Value = numericUpDown1.Value - 1;
            }
            if(Convert.ToInt32(numericUpDown1.Value) > 0)
            {
                int total = Convert.ToInt32(txtPrice.Text) * Convert.ToInt32(numericUpDown1.Value);
                txtTotal.Text = total.ToString();
            }      
        }

        private void customerGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtCUId.Text = customerGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtCUName.Text = customerGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
        }

        private void productGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtPDId.Text = productGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtPDName.Text = productGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtPrice.Text = productGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
        }

        private void insertButton_Click(object sender, EventArgs e)
        {
            if (txtCUId.Text == "")
            {
                MessageBox.Show("Please select customer!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (txtPDId.Text == "")
            {
                MessageBox.Show("Please select product!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                if (MessageBox.Show("Are you sure you want to insert this order?", "Saving", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cm = new SqlCommand("INSERT INTO tbOrder(odate,pid,cid,quantity,price,total)VALUES(@odate,@pid,@cid,@quantity,@price,@total)", con);
                    cm.Parameters.AddWithValue("@odate", dtOrder.Value);
                    cm.Parameters.AddWithValue("@pid", Convert.ToInt32(txtPDId.Text));
                    cm.Parameters.AddWithValue("@cid", Convert.ToInt32(txtCUId.Text));
                    cm.Parameters.AddWithValue("@quantity", Convert.ToInt32(numericUpDown1.Value));
                    cm.Parameters.AddWithValue("@price", Convert.ToInt32(txtPrice.Text));
                    cm.Parameters.AddWithValue("@total", Convert.ToInt32(txtTotal.Text));
                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Order successfully Saved");

                    cm = new SqlCommand("UPDATE tbProduct SET pquantity=(pquantity-@pquantity) WHERE pid LIKE '" + txtPDId.Text + "' ", con);
                    cm.Parameters.AddWithValue("@pquantity", Convert.ToInt16(numericUpDown1.Text));
                    
                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();
                    Clear();
                    LoadProduct();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void Clear()
        {
            txtCUId.Clear();
            txtCUName.Clear();

            txtPDId.Clear();
            txtPDName.Clear();

            txtPrice.Clear();
            numericUpDown1.Value = 0;
            txtTotal.Clear();
            dtOrder.Value = DateTime.Now;
        }
        private void clearButton_Click(object sender, EventArgs e)
        {
            Clear();
        }
        public void GetQty()
        {
            if (string.IsNullOrEmpty(txtPDId.Text))
                return;

            cm = new SqlCommand(
                "SELECT pquantity FROM tbProduct WHERE pid = @pid", con);

            cm.Parameters.AddWithValue("@pid", txtPDId.Text);

            con.Open();
            dr = cm.ExecuteReader();

            if (dr.Read())
            {
                quantity = Convert.ToInt32(dr["pquantity"]);
            }

            dr.Close();
            con.Close();
        }
    }
}
