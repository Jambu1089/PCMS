﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Mainform : Form
    {
        private string userRole;
        public Mainform()
        {
            InitializeComponent();
        }
        public Mainform(string role)
        {
            InitializeComponent();
            userRole = role;
            ApplyRolePermissions();
        }

        private void ApplyRolePermissions()
        {
            if (userRole == "Admin")
            {
                // Full access
                userBtn.Visible = true;
                productBtn.Visible = true;
                categoryBtn.Visible = true;
                customerBtn.Visible = true;
                orderBtn.Visible = true;
            }
            else if (userRole == "Staff")
            {
                userBtn.Visible = false;
                orderBtn.Visible = false;
                productBtn.Visible = true;
                categoryBtn.Visible = true;
                customerBtn.Visible = true;
                label5.Visible = false;
                label6.Visible = false;
            }
            else if (userRole == "Cashier")
            {
                userBtn.Visible = false;
                productBtn.Visible = false;
                categoryBtn.Visible = false;
                customerBtn.Visible = true;
                orderBtn.Visible = true;
                label2.Visible = false;
                label4.Visible = false;
                label5.Visible = false;
            }
        }

        private void Logout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to log out?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                LoginForm login = new LoginForm();
                login.Show();
                this.Hide();
            } 
        }

        //to show sub form inside the main form 
        private Form activeForm = null;
        private void openChildform(Form childForm)
        {
            if(activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelMain.Controls.Add(childForm);
            panelMain.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
        private void productBtn_Click(object sender, EventArgs e)
        {
            openChildform(new ProductForm());
        }

        private void customerBtn_Click(object sender, EventArgs e)
        {
            openChildform(new CustomerForm());
        }

        private void categoryBtn_Click(object sender, EventArgs e)
        {
            openChildform(new CategoryForm());
        }

        private void userBtn_Click(object sender, EventArgs e)
        {
            openChildform(new UserForm());
        }

        private void orderBtn_Click(object sender, EventArgs e)
        {
            openChildform(new OrderForm());
        }
    }
}
