﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class CategoryModuleForm : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Administrator\Desktop\PCMS Project\dbPC.mdf;Integrated Security=True;");
        SqlCommand cm = new SqlCommand();
        public CategoryModuleForm()
        {
            InitializeComponent();
        }
        private bool ValidateFields()
        {
            if (string.IsNullOrWhiteSpace(txtCTName.Text))
            {
                MessageBox.Show("Please fill in all fields.", "Validation Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (!ValidateFields())
            {
                return;
            }
            try
            {
                if (MessageBox.Show("Are you sure you want to save this category?", "Saving", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cm = new SqlCommand("INSERT INTO tbCategory(ctname)VALUES(@ctname)", con);
                    cm.Parameters.AddWithValue("@ctname", txtCTName.Text);
                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Category successfully Saved");
                    Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void Clear()
        {
            txtCTName.Clear();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            if (!ValidateFields())
            {
                return;
            }
            try
            {
                if (MessageBox.Show("Are you sure you want to update this Category?", "Updating", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cm = new SqlCommand("UPDATE tbCategory SET ctname=@ctname WHERE ctid LIKE '" + categoryId.Text + "' ", con);
                    cm.Parameters.AddWithValue("@ctname", txtCTName.Text);
                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Category successfully Updated");
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            Clear();
            saveButton.Enabled = true;
            updateButton.Enabled = false;
        }
        private void txtCTName_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCTName.Text))
            {
                errorProvider1.SetError(txtCTName, "Name cannot be empty");
                txtCTName.Focus();
            }
            else
            {
                errorProvider1.SetError(txtCTName, "");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
