﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class CategoryForm : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Administrator\Desktop\PCMS Project\dbPC.mdf;Integrated Security=True;");
        SqlCommand cm = new SqlCommand();
        SqlDataReader dr;
        public CategoryForm()
        {
            InitializeComponent();
            LoadCategory();
        }
        public void LoadCategory()
        {
            int i = 0;
            categoryGridView.Rows.Clear();
            cm = new SqlCommand("SELECT * FROM tbCategory", con);
            con.Open();
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                categoryGridView.Rows.Add(i, dr[0].ToString(), dr[1].ToString());
            }
            dr.Close();
            con.Close();
        }

        private void categoryGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = categoryGridView.Columns[e.ColumnIndex].Name;
            if (colName == "Edit")
            {
                CategoryModuleForm categoryModule = new CategoryModuleForm();
                categoryModule.categoryId.Text = categoryGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
                categoryModule.txtCTName.Text = categoryGridView.Rows[e.RowIndex].Cells[2].Value.ToString();

                categoryModule.saveButton.Enabled = false;
                categoryModule.updateButton.Enabled = true;
                categoryModule.ShowDialog();
            }
            else if (colName == "Delete")
            {
                if (MessageBox.Show("Are you sure you want to delete this user?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    con.Open();
                    cm = new SqlCommand("DELETE FROM tbCategory WHERE ctId LIKE '" + categoryGridView.Rows[e.RowIndex].Cells[1].Value.ToString() + "'", con);
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Successfully Deleted");
                }
            }
            LoadCategory();
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            CategoryModuleForm moduleForm4 = new CategoryModuleForm();
            moduleForm4.saveButton.Enabled = true;
            moduleForm4.updateButton.Enabled = false;
            moduleForm4.ShowDialog();
            LoadCategory();
        }
    }
}
