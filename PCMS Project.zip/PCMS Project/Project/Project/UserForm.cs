﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class UserForm : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Administrator\Desktop\PCMS Project\dbPC.mdf;Integrated Security=True;");
        SqlCommand cm = new SqlCommand();
        SqlDataReader dr;

        public UserForm()
        {
            InitializeComponent();
            LoadUser();
        }

        public void LoadUser()
        {
            int i = 0;
            userGridView.Rows.Clear();
            cm = new SqlCommand("SELECT * FROM tbUser", con);
            con.Open();
            dr = cm.ExecuteReader();
            while(dr.Read())
            {
                i++;
                userGridView.Rows.Add(i,dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString());
            }
            dr.Close();
            con.Close();
        }

        private void userGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = userGridView.Columns[e.ColumnIndex].Name;

            if (colName == "Edit")
            {
                UserModuleForm userModule = new UserModuleForm();
                int id = Convert.ToInt32(userGridView.Rows[e.RowIndex].Cells[1].Value);
                userModule.UserId = id;
                userModule.LoadUserId();
                userModule.UserId = Convert.ToInt32(userGridView.Rows[e.RowIndex].Cells[1].Value);
                userModule.txtUserName.Text = userGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
                userModule.txtFullName.Text = userGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
                userModule.txtPass.Text = userGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
                userModule.txtPhone.Text = userGridView.Rows[e.RowIndex].Cells[5].Value.ToString();
                userModule.cmbRole.Text = userGridView.Rows[e.RowIndex].Cells[6].Value.ToString();


                userModule.saveButton.Enabled = false;
                userModule.updateButton.Enabled = true;
                userModule.txtUserName.Enabled = false;
                userModule.ShowDialog();
                userModule.lblUserId.Text = userModule.UserId.ToString();
            }
            else if(colName == "Delete")
            {
                if(MessageBox.Show("Are you sure you want to delete this user?","Delete Record",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
                {
                    con.Open();
                    cm = new SqlCommand("DELETE FROM tbUser WHERE uid = @uid",con);
                    cm.Parameters.AddWithValue("@uid", Convert.ToInt32(userGridView.Rows[e.RowIndex].Cells[1].Value));
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Successfully Deleted");
                }
            }
            LoadUser();
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            UserModuleForm moduleForm1 = new UserModuleForm();
            moduleForm1.saveButton.Enabled = true;
            moduleForm1.updateButton.Enabled = false;
            moduleForm1.UserId = 0;
            moduleForm1.txtUserId.Text = "Auto-generated";
            moduleForm1.ShowDialog();
            LoadUser();
        }
    }
}
